module.exports=[21733,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_quiz_page_actions_0hl_z5-.js.map