module.exports=[12126,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_sub-lesson_page_actions_0_3~d0-.js.map