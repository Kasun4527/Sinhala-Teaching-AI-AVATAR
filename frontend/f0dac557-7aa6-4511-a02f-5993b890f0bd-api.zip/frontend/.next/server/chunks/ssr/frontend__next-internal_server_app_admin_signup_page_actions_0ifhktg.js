module.exports=[23190,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_admin_signup_page_actions_0ifhktg.js.map