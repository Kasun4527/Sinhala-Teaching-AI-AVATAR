module.exports=[90127,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_result_page_actions_0ko-f2f.js.map