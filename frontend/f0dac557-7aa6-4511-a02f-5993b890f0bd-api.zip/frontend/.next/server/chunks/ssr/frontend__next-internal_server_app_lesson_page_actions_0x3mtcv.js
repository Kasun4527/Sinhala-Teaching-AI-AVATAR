module.exports=[92580,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_lesson_page_actions_0x3mtcv.js.map