module.exports=[36307,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_user-details_page_actions_0shwl-u.js.map