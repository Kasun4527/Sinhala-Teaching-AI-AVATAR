module.exports=[93551,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_topics_page_actions_0td.zoc.js.map