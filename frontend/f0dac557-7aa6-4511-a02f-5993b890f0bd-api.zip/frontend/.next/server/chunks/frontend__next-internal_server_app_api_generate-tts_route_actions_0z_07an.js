module.exports=[72010,(e,o,d)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_api_generate-tts_route_actions_0z_07an.js.map