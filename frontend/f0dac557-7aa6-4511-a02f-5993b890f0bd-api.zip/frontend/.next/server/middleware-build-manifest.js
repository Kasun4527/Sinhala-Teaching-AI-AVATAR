globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/SFSLKHP92pDr7UYwUNGTw/_buildManifest.js",
    "static/SFSLKHP92pDr7UYwUNGTw/_ssgManifest.js",
    "static/SFSLKHP92pDr7UYwUNGTw/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0phozgm3131qt.js",
    "static/chunks/17vjdk0jajkb0.js",
    "static/chunks/0n--d.s46ny6r.js",
    "static/chunks/0tdo70qqcccz~.js",
    "static/chunks/turbopack-0.~6m9lqnl_qj.js"
  ]
};
