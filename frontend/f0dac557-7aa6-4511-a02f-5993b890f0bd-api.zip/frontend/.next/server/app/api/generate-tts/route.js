var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate-tts/route.js")
R.c("server/chunks/[root-of-the-server]__0-v.v1s._.js")
R.c("server/chunks/[root-of-the-server]__0ji~3va._.js")
R.c("server/chunks/[root-of-the-server]__09ymuk_._.js")
R.c("server/chunks/frontend__next-internal_server_app_api_generate-tts_route_actions_0z_07an.js")
R.m(2556)
module.exports=R.m(2556).exports
